//
//  SecViewController.h
//  kwt
//
//  Created by qianfeng on 12-4-19.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SecViewController : UIViewController

@end
