//
//  RootViewController.m
//  kwt
//
//  Created by qianfeng on 12-4-19.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "RootViewController.h"
#import <QuartzCore/QuartzCore.h>

@implementation RootViewController


static int ii=1;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle


-(void)segmenedtAct:(UISegmentedControl*)segc
{
    NSInteger index=segc.selectedSegmentIndex;
    
    if (index==0) {
        NSLog(@"dsadasd");
    }
    else if(index==1)
    {
        NSLog(@"ddddddd");
    }
    
}


- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
   // self.navigationItem.titleView=[[UIImageView alloc] initWithImage:[UIImage imageNamed:@"logo.png"]];
    
    UISegmentedControl* segc=[[UISegmentedControl alloc] initWithFrame:CGRectMake(80, 8, 80, 30)];
    
    [segc insertSegmentWithTitle:@"热门" atIndex:0 animated:YES];
    [segc insertSegmentWithTitle:@"全部" atIndex:1 animated:YES];
//    [segc insertSegmentWithImage:@"" atIndex:2 animated:YES];
    
    segc.segmentedControlStyle=UISegmentedControlStyleBar;
    
    segc.momentary=YES;
    segc.multipleTouchEnabled=NO;
//    segc.userInteractionEnabled=YES;
    
    [segc addTarget:self action:@selector(segmenedtAct:) forControlEvents:UIControlEventValueChanged];
    //segc.tintColor=[UIColor colorWithRed:104/255 green:197/255 blue:178/255 alpha:0];
    segc.tintColor=[UIColor lightTextColor];
    UIBarButtonItem* homeBarItem=[[UIBarButtonItem alloc]initWithCustomView:segc];
    self.navigationItem.rightBarButtonItem=homeBarItem;
    
    UIImageView* logo=[[UIImageView alloc] initWithFrame:CGRectMake(5, 5, 80, 40)];
    [logo setImage:[UIImage imageNamed:@"logo.png"]];
    
    [self.navigationController.navigationBar addSubview:logo];
    
    Count=1;
    
    flowView=[[LLWaterFlowView alloc]initWithFrame:CGRectMake(0, 0, 320, 360)];
    flowView.flowdelegate=self;
    
    flowView.backgroundColor=[UIColor whiteColor];
    //[flowView setContentOffset:CGPointMake(0, 300) animated:YES];
    [self.view addSubview:flowView];
    //[flowView release];
    

}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

- (NSUInteger)numberOfColumnsInFlowView:(LLWaterFlowView *)flowView
{
	return 3;
}
- (NSInteger)flowView:(LLWaterFlowView *)flowView numberOfRowsInColumn:(NSInteger)column
{
	return  Count*3;
}

-(void)didselected:(id)sender IndexPath:(NSIndexPath *)indexPath
{
    NSLog(@"iiiiiiiiii%@",indexPath.row);
}



- (LLWaterFlowCell *)flowView:(LLWaterFlowView *)flowView_ cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
	static NSString *CellIdentifier = @"CellTag_Airport_weather";
	LLWaterFlowCell *cell = [flowView_ dequeueReusableCellWithIdentifier:CellIdentifier];
	
	if(cell == nil)
	{
		cell  = [[[LLWaterFlowCell alloc] initWithIdentifier:CellIdentifier] autorelease];
		
//		UIImageView *iv = [[UIImageView alloc] initWithFrame:CGRectZero];
//		[cell addSubview:iv];
//		iv.layer.borderColor = [[UIColor whiteColor] CGColor];
//		iv.layer.borderWidth = 1;
//		[iv release];
//		iv.tag = 101;
        
        
        UIButton* but=[[UIButton alloc]initWithFrame:CGRectZero];
        
       // UIButton* but=[[UIButton buttonWithType:UIButtonTypeCustom] retain];
       // [but setImage:[UIImage imageNamed:@"img9.png"] forState:UIControlStateNormal];
        
        [cell addSubview:but];
        
        
        
        but.layer.borderColor=[[UIColor grayColor] CGColor];
        but.layer.borderWidth=1;
        [but release];
        
        but.tag=101;
        
		
		UILabel *label = [[UILabel alloc] initWithFrame:CGRectZero];
		label.backgroundColor = [UIColor clearColor];
		[cell addSubview:label];
		label.textAlignment = UITextAlignmentCenter;
		label.font = [UIFont boldSystemFontOfSize:30];
		label.shadowOffset = CGSizeMake(0, 1);
		label.shadowColor = [UIColor redColor];
		label.textColor = [UIColor whiteColor];
		[label release];
		label.tag = 102;
	}
	
	else 
	{
		NSLog(@"此条是从重用列表中获取的。。。。。");
	}
    
	
	float hei = [self flowView:nil heightForRowAtIndexPath:indexPath];
	
//	UIImageView *iv  = (UIImageView *)[cell viewWithTag:101];
//	iv.frame = CGRectMake(3, 3, 103, hei - 3);
//	iv.image = [UIImage imageNamed:[NSString stringWithFormat:@"img%d.png", (indexPath.row + indexPath.section + 1)  % 7 + 1]];
//	
//    iv.image = [UIImage imageNamed:[NSString stringWithFormat:@"img%d.png", (indexPath.row + indexPath.section + 1)]];
//    i
    
    //NSLog(@"img%d.png",(indexPath.row + indexPath.section + 1));
//	UILabel *label = (UILabel *)[cell viewWithTag:102];
//	label.frame = CGRectMake(3, 5, 100, hei - 10);
//	label.text = [NSString stringWithFormat:@"%d", indexPath.row];
	
    UIButton* bu=(UIButton*)[cell viewWithTag:101];
    
    
    
    bu.frame=CGRectMake(3, 3, 103, hei-3);
    [bu setImage:[UIImage imageNamed:[NSString stringWithFormat:@"img%d.png",indexPath.row+indexPath.section +1]] forState:UIControlStateNormal];
   // [bu addTarget:self action:@selector(didselected:IndexPath:) forControlEvents:UIControlEventTouchUpInside];
     
//    NSLog(@"ii%d,",ii);
//    NSLog(@"img%d.png",indexPath.row+indexPath.section +1);
//   NSLog(@"row%d",indexPath.row);
//    NSLog(@"section%d",indexPath.section);
	return cell;
}



- (CGFloat)flowView:(LLWaterFlowView *)flowView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
	
	float heigth= 0;
//	switch ((indexPath.row + indexPath.section + 1)  % 7) {
//		case 0:
//			heigth = 147 + 10;
//			break;
//		case 1:
//			heigth = 240 + 10;
//			break;
//		case 2:
//			heigth = 200 + 10;
//			break;
//		case 3:
//			heigth = 150 + 10;
//			break;
//		case 4:
//			heigth = 147 + 10;
//			break;
//		case 5:
//			heigth = 200 + 10;
//			break;
//            
//		case 6:
//			heigth = 100 + 10;
//			break;
//		case 7:
//			heigth = 127 + 10;
//			break;
//            
//		default:
//			break;
//	}
//	
//	heigth += (indexPath.section *2);
    
    
    
    
    
    NSString* str=[NSString stringWithFormat:@"img%d.png",indexPath.row+indexPath.section +1];
    UIImage* image=[UIImage imageNamed:str];
    NSLog(@"ii%d,",ii);
    NSLog(@"///////////////////");
	//UIImage* image=[UIImage imageNamed:@"img9.png"];
    
    NSLog(@"height%f",image.size.height);
    if (image.size.height<300) {
        heigth=image.size.height/1.7;
    }
    else if(image.size.height>=300 && image.size.height<600)
    {
        heigth=image.size.height/2.5;
    }
    else if(image.size.height>=600 )
    {
        heigth=image.size.height/5;
    }
    
	return heigth;
}




@end
